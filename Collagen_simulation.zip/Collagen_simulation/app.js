// app.js - Main logic for 3D Quantum-Inspired Collagen Lattice Simulation

// ==========================================
// 1. Simulation State & Biophysics
// ==========================================
window.simNodes = [];
window.simLinks = [];
window.selectedNodeId = null;

window.CONFIG = {
  antigravityActive: true,
  speed: 2.0,
  upperBoundary: 35,
  lowerBoundary: -35
};

window.COLLAGEN_ENV = {
  temperature: 37.0,       // Celsius
  denaturationTemp: 41.5,  // Threshold where triple helix denatures
  glycationLevel: 0.1,     // AGEs cross-links (0.0 to 1.0)
  stiffness: 1.0
};

// Node colors
const COLORS = {
  intact: new THREE.Color(0x10b981),
  damaged: new THREE.Color(0xef4444),
  repairing: new THREE.Color(0xf59e0b),
  repaired: new THREE.Color(0x4f46e5)
};

const LINK_COLORS = {
  intact: new THREE.Color(0xffffff),
  damaged: new THREE.Color(0xef4444)
};

// ==========================================
// 2. Three.js 3D Lattice Simulation
// ==========================================
let scene, camera, renderer, raycaster, mouse;
let nodeMesh, bondMesh, latticeGroup;
let animationFrameId;

const initThreeJS = () => {
  const container = document.getElementById('three-canvas');
  if (!container) return;

  const width = container.clientWidth;
  const height = container.clientHeight;

  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x050507); // Match dark theme
  scene.fog = new THREE.FogExp2(0x050507, 0.015);

  camera = new THREE.PerspectiveCamera(60, width / height, 0.1, 1000);
  camera.position.set(0, 0, 70);

  renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
  renderer.setSize(width, height);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  container.appendChild(renderer.domElement);

  // Lights
  const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
  scene.add(ambientLight);
  const dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
  dirLight.position.set(10, 20, 10);
  scene.add(dirLight);
  const pointLight = new THREE.PointLight(0x4f46e5, 1, 100);
  pointLight.position.set(-10, 0, 20);
  scene.add(pointLight);

  // Raycaster for interaction
  raycaster = new THREE.Raycaster();
  mouse = new THREE.Vector2();

  latticeGroup = new THREE.Group();
  latticeGroup.rotation.z = Math.PI / 8; // Slight diagonal tilt
  scene.add(latticeGroup);

  // Build initial lattice
  buildLattice(parseInt(document.getElementById('nodes-slider').value) || 250);

  // Mouse Interaction
  let targetRotationX = 0;
  let targetRotationY = 0;

  container.addEventListener('mousemove', (event) => {
    const rect = container.getBoundingClientRect();
    mouse.x = ((event.clientX - rect.left) / width) * 2 - 1;
    mouse.y = -((event.clientY - rect.top) / height) * 2 + 1;
    
    targetRotationY = mouse.x * 0.5;
    targetRotationX = -mouse.y * 0.5;
  });

  container.addEventListener('click', () => {
    raycaster.setFromCamera(mouse, camera);
    if (!nodeMesh) return;
    const intersects = raycaster.intersectObject(nodeMesh);
    if (intersects.length > 0) {
      const instanceId = intersects[0].instanceId;
      const clickedNode = window.simNodes[instanceId];
      if (window.selectedNodeId === clickedNode.id) {
        window.selectedNodeId = null; // deselect
      } else {
        window.selectedNodeId = clickedNode.id;
      }
      updateSelectionUI();
      updateVisuals();
    } else {
      window.selectedNodeId = null;
      updateSelectionUI();
      updateVisuals();
    }
  });

  // Animation Loop
  const clock = new THREE.Clock();
  const dummyNode = new THREE.Object3D();
  
  function animate() {
    animationFrameId = requestAnimationFrame(animate);
    const delta = Math.min(clock.getDelta(), 0.1);
    const time = clock.getElapsedTime();

    // Rotate lattice
    latticeGroup.rotation.y += 0.1 * delta;
    
    // Interactive parallax
    latticeGroup.rotation.x += (targetRotationX - latticeGroup.rotation.x) * 5 * delta;
    latticeGroup.rotation.y += (targetRotationY - latticeGroup.rotation.y) * 5 * delta;

    // Antigravity Effect
    if (window.CONFIG.antigravityActive && nodeMesh && bondMesh) {
      for (let i = 0; i < window.simNodes.length; i++) {
        let node = window.simNodes[i];
        node.y += window.CONFIG.speed * delta;
        node.x += Math.sin(time * 2 + node.id) * 0.05; // sinusoidal fluctuation
        node.z += Math.cos(time * 2 + node.id) * 0.05;

        if (node.y > window.CONFIG.upperBoundary) {
          node.y = window.CONFIG.lowerBoundary;
        }
        
        dummyNode.position.set(node.x, node.y, node.z);
        dummyNode.updateMatrix();
        nodeMesh.setMatrixAt(i, dummyNode.matrix);
      }
      nodeMesh.instanceMatrix.needsUpdate = true;

      for (let i = 0; i < window.simLinks.length; i++) {
        updateBondMatrix(window.simLinks[i], i);
      }
      bondMesh.instanceMatrix.needsUpdate = true;
    }

    renderer.render(scene, camera);
  }
  animate();

  window.addEventListener('resize', () => {
    const w = container.clientWidth;
    const h = container.clientHeight;
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    renderer.setSize(w, h);
  });
};

const buildLattice = (particleCount) => {
  // Clear old meshes
  if (nodeMesh) {
    latticeGroup.remove(nodeMesh);
    nodeMesh.geometry.dispose();
    nodeMesh.material.dispose();
  }
  if (bondMesh) {
    latticeGroup.remove(bondMesh);
    bondMesh.geometry.dispose();
    bondMesh.material.dispose();
  }

  window.simNodes = [];
  window.simLinks = [];

  const radius = 20;
  const cylHeight = 70;
  
  // Initialize nodes
  for (let i = 0; i < particleCount; i++) {
    const r = Math.sqrt(Math.random()) * radius;
    const theta = Math.random() * Math.PI * 2;
    const y = (Math.random() - 0.5) * cylHeight;
    
    window.simNodes.push({
      id: i,
      x: r * Math.cos(theta),
      y: y,
      z: r * Math.sin(theta),
      health: 1.0,
      status: 'intact',
      wave: 0,
      wavePrev: 0,
      damageHistory: 0,
      localTemperature: window.COLLAGEN_ENV.temperature
    });
  }

  // Initialize links
  const maxDistance = 10;
  for (let i = 0; i < window.simNodes.length; i++) {
    for (let j = i + 1; j < window.simNodes.length; j++) {
      const n1 = window.simNodes[i];
      const n2 = window.simNodes[j];
      const dx = n1.x - n2.x;
      const dy = n1.y - n2.y;
      const dz = n1.z - n2.z;
      const dist = Math.sqrt(dx*dx + dy*dy + dz*dz);
      
      if (dist < maxDistance) {
        window.simLinks.push({
          source: n1,
          target: n2,
          intact: true,
          distance: dist
        });
      }
    }
  }

  // InstancedMesh for Nodes
  const nodeGeo = new THREE.SphereGeometry(1.2, 16, 16);
  const nodeMat = new THREE.MeshPhongMaterial({
    color: 0xffffff,
    emissive: 0x111111,
    shininess: 60
  });
  nodeMesh = new THREE.InstancedMesh(nodeGeo, nodeMat, window.simNodes.length);
  nodeMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  
  const dummy = new THREE.Object3D();
  window.simNodes.forEach((node, i) => {
    dummy.position.set(node.x, node.y, node.z);
    dummy.updateMatrix();
    nodeMesh.setMatrixAt(i, dummy.matrix);
    nodeMesh.setColorAt(i, COLORS.intact);
  });
  latticeGroup.add(nodeMesh);

  // InstancedMesh for Bonds (Cylinders)
  const bondGeo = new THREE.CylinderGeometry(0.25, 0.25, 1, 8);
  const bondMat = new THREE.MeshPhongMaterial({
    color: 0xffffff,
    transparent: true,
    opacity: 0.6
  });
  bondMesh = new THREE.InstancedMesh(bondGeo, bondMat, window.simLinks.length);
  bondMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);

  window.simLinks.forEach((link, i) => {
    updateBondMatrix(link, i);
    bondMesh.setColorAt(i, LINK_COLORS.intact);
  });
  latticeGroup.add(bondMesh);

  updateVisuals();
  logStep(`Built new lattice with ${particleCount} nodes.`, 'var(--text-muted)');
};

const _dummyBond = new THREE.Object3D();
const _v1 = new THREE.Vector3();
const _v2 = new THREE.Vector3();
const _v3 = new THREE.Vector3();
const _dir = new THREE.Vector3();
const _up = new THREE.Vector3(0, 1, 0);

function updateBondMatrix(link, index) {
  if (!bondMesh) return;
  _v1.set(link.source.x, link.source.y, link.source.z);
  _v2.set(link.target.x, link.target.y, link.target.z);
  const distance = link.intact ? _v1.distanceTo(_v2) : 0.001; 
  const position = _v3.copy(_v2).add(_v1).divideScalar(2);

  _dummyBond.position.copy(position);
  if (link.intact) {
    _dummyBond.scale.set(1, distance, 1);
    _dir.copy(_v2).sub(_v1).normalize();
    _dummyBond.quaternion.setFromUnitVectors(_up, _dir);
  } else {
    _dummyBond.scale.set(0, 0, 0);
  }
  _dummyBond.updateMatrix();
  bondMesh.setMatrixAt(index, _dummyBond.matrix);
}

// ==========================================
// 3. Logic & Visual Updates
// ==========================================

const updateSelectionUI = () => {
  const infoEl = document.getElementById('selected-node-info');
  const btnEl = document.getElementById('btn-perturb-selected');
  if (!infoEl || !btnEl) return;

  if (window.selectedNodeId !== null) {
    const node = window.simNodes.find(n => n.id === window.selectedNodeId);
    if (node) {
      infoEl.innerHTML = `
        <div>ID: ${node.id}</div>
        <div>Health: ${(node.health * 100).toFixed(1)}%</div>
        <div>Status: ${node.status}</div>
        <div>Fatigue: ${node.damageHistory}</div>
        <div style="color: ${node.localTemperature >= window.COLLAGEN_ENV.denaturationTemp ? '#ef4444' : 'var(--text-main)'}">Local Temp: ${node.localTemperature.toFixed(1)} °C</div>
      `;
      btnEl.style.display = 'block';
    }
  } else {
    infoEl.innerHTML = `None`;
    btnEl.style.display = 'none';
  }
};

const updateVisuals = () => {
  if (!nodeMesh || !bondMesh) return;

  // Update node colors
  const highlightColor = new THREE.Color(0xffff00);
  window.simNodes.forEach((node, i) => {
    if (window.selectedNodeId === node.id) {
      nodeMesh.setColorAt(i, highlightColor);
    } else {
      nodeMesh.setColorAt(i, COLORS[node.status]);
    }
  });
  nodeMesh.instanceColor.needsUpdate = true;

  // Update bond matrices and colors
  window.simLinks.forEach((link, i) => {
    updateBondMatrix(link, i);
    bondMesh.setColorAt(i, link.intact ? LINK_COLORS.intact : LINK_COLORS.damaged);
  });
  bondMesh.instanceMatrix.needsUpdate = true;
  bondMesh.instanceColor.needsUpdate = true;

  updateMetrics();
  updateSelectionUI();
};

const logStep = (msg, color = 'var(--text-main)') => {
  const logPanel = document.getElementById('process-log');
  if (!logPanel) return;
  const entry = document.createElement('div');
  entry.className = 'log-entry';
  entry.style.color = color;
  entry.innerText = msg;
  logPanel.prepend(entry);
  
  if (logPanel.children.length > 50) {
    logPanel.removeChild(logPanel.lastChild);
  }
};

const applyDamage = (centerId, probability) => {
  const centerNode = window.simNodes.find(n => n.id === centerId);
  if (!centerNode) return;
  
  document.getElementById('sim-status').innerText = 'DTQW PERTURBATION';
  document.getElementById('sim-status').style.color = '#ef4444';
  logStep(`[!] Discrete-Time Quantum Walk (DTQW) initiated at node ${centerId}`, '#ef4444');

  // Initialize amplitudes for DTQW
  window.simNodes.forEach(n => {
    n.wave = 0;
    n.wavePrev = 0;
  });
  centerNode.wave = 1.0;
  centerNode.wavePrev = 1.0;

  let step = 0;
  const maxSteps = 15;
  const waveSpeed = 0.3; // Coupling constant

  const expandWave = () => {
    if (step > maxSteps) {
      document.getElementById('sim-status').innerText = 'IDLE';
      document.getElementById('sim-status').style.color = 'var(--text-main)';
      logStep(`[✓] DTQW interference resolved. Perturbation complete.`, 'var(--text-muted)');
      return;
    }
    
    let nextWave = new Array(window.simNodes.length).fill(0);
    let damageCount = 0;

    // Simulate discrete wave equation / DTQW Laplacian interference
    window.simNodes.forEach((n, i) => {
      let laplacianSum = 0;
      let degree = 0;
      
      window.simLinks.forEach(l => {
        if (l.intact) {
          if (l.source.id === n.id) { laplacianSum += l.target.wave; degree++; }
          if (l.target.id === n.id) { laplacianSum += l.source.wave; degree++; }
        }
      });

      let L_val = (degree * n.wave) - laplacianSum;
      
      // Compute next amplitude with constructive/destructive interference
      nextWave[i] = 2 * n.wave - n.wavePrev - waveSpeed * L_val;
      nextWave[i] *= 0.95; // slight dampening
      
      // Calculate damage based on probability amplitude squared
      let probAmp = nextWave[i] * nextWave[i];
      if (probAmp > 0.05 * (1.0 - probability)) { // Map slider to sensitivity
        // Add local heat based on dissipated amplitude energy
        n.localTemperature += probAmp * 15;
        let isDenatured = n.localTemperature >= window.COLLAGEN_ENV.denaturationTemp;

        n.health = Math.max(0, n.health - probAmp * 0.5);
        if (n.health < 0.5 && n.status !== 'damaged') {
           n.status = 'damaged';
           n.damageHistory++;
           damageCount++;
        }
        
        // Disconnect bonds locally based on high amplitude OR thermal denaturation
        window.simLinks.forEach(l => {
          if ((l.source.id === n.id || l.target.id === n.id) && (isDenatured || Math.random() < probAmp * probability)) {
            l.intact = false;
          }
        });
      }
    });

    // Commit wave state
    window.simNodes.forEach((n, i) => {
      n.wavePrev = n.wave;
      n.wave = nextWave[i];
    });

    if (damageCount > 0) logStep(`DTQW step ${step}: ${damageCount} tropocollagen node(s) destabilized via interference.`);

    step++;
    updateVisuals();
    
    setTimeout(expandWave, 100); // Fast wave propagation
  };

  expandWave();
};

const simulateQAOA = (pDepth) => {
  document.getElementById('sim-status').innerText = `QAOA REPAIR (p=${pDepth})`;
  document.getElementById('sim-status').style.color = '#007fff';
  logStep(`Initializing QAOA Ansatz with depth p=${pDepth}`, '#007fff');

  let damagedNodes = window.simNodes.filter(n => n.status === 'damaged' || n.status === 'repairing');
  
  let step = 0;

  // 1. Calculate dynamic maxPossibleHealth per node based on global environment
  const globalGlycation = window.COLLAGEN_ENV.glycationLevel;
  const temp = window.COLLAGEN_ENV.temperature;
  const denatTemp = window.COLLAGEN_ENV.denaturationTemp;
  
  let globalMaxHealth = 1.0 - (globalGlycation * 0.4);
  let isDenatured = false;

  if (temp >= denatTemp) {
    globalMaxHealth = Math.min(globalMaxHealth, 0.35);
    isDenatured = true;
    logStep(`[WARNING] Temperature >= ${denatTemp}°C! Triple helix denatured. Max recovery capped at ${globalMaxHealth.toFixed(2)}`, '#ef4444');
  } else if (temp > 37.0) {
    globalMaxHealth -= (temp - 37.0) * 0.12;
    logStep(`[WARNING] Elevated temperature (${temp}°C) causing thermal fatigue. Cap: ${globalMaxHealth.toFixed(2)}`, '#f59e0b');
  }

  damagedNodes.forEach(n => {
    n.maxPossibleHealth = Math.max(0.0, globalMaxHealth - (0.15 * n.damageHistory));
    if (n.localTemperature >= denatTemp) {
      n.maxPossibleHealth = Math.min(n.maxPossibleHealth, 0.35);
    }
  });

  const repairStep = () => {
    damagedNodes = window.simNodes.filter(n => n.status === 'damaged' || n.status === 'repairing');
    
    if (step >= pDepth || damagedNodes.length === 0) {
      document.getElementById('sim-status').innerText = 'IDLE';
      document.getElementById('sim-status').style.color = 'var(--text-main)';
      logStep(`[✓] QAOA routine finished at p=${step}.`, '#10b981');
      return;
    }

    logStep(`Applying quantum layer ${step + 1}: optimizing repair pathways...`);

    // 2. Evaluate Cost Hamiltonian & Neighborhood Penalty
    damagedNodes.forEach(n => {
      n.status = 'repairing';
      
      // Calculate Neighborhood Penalty
      let heavyDamageNeighbors = 0;
      window.simLinks.forEach(l => {
        let neighbor = null;
        if (l.source.id === n.id) neighbor = l.target;
        else if (l.target.id === n.id) neighbor = l.source;
        
        if (neighbor && neighbor.health < 0.4) {
          heavyDamageNeighbors++;
        }
      });
      
      let couplingPenalty = Math.max(0.1, 1.0 - (heavyDamageNeighbors * 0.15));
      
      // Calculate 3D Helical Penalty (Long-Range Cross-Linking)
      let helicalPenalty = 0;
      window.simNodes.forEach(other => {
        if (other.id !== n.id && (other.status === 'damaged' || other.status === 'repairing')) {
          let deltaTheta = Math.abs(Math.atan2(other.z, other.x) - Math.atan2(n.z, n.x));
          if (deltaTheta > Math.PI) deltaTheta = 2 * Math.PI - deltaTheta;
          if (deltaTheta < 0.2 && Math.abs(other.y - n.y) > 5) {
             helicalPenalty += 0.2;
          }
        }
      });
      let helicalMultiplier = Math.max(0.1, 1.0 - helicalPenalty);

      // 3. QAOA Layer Convergence (Slow asymptotic step to force high pDepth requirement)
      let distanceToCeiling = Math.max(0, n.maxPossibleHealth - n.health);
      
      // A small quantum step that requires multiple p-layers to cross the gap
      let repairDelta = distanceToCeiling * 0.25; 
      
      // Apply coupling penalty and helical penalty
      repairDelta *= couplingPenalty * helicalMultiplier;

      n.health = Math.min(n.maxPossibleHealth, n.health + repairDelta);
    });
    
    updateVisuals();

    setTimeout(() => {
      let repairedThisStep = 0;
      damagedNodes.forEach(n => {
        // Mark repaired if it gets within 2% of its theoretical max
        if (n.health >= n.maxPossibleHealth - 0.02) {
          n.status = 'repaired';
          repairedThisStep++;
          window.simLinks.forEach(l => {
            if (l.source.id === n.id || l.target.id === n.id) {
              l.intact = true;
            }
          });
        }
      });
      
      if(repairedThisStep > 0) logStep(`Converged ${repairedThisStep} nodes to max possible state.`);

      step++;
      updateVisuals();
      
      damagedNodes = window.simNodes.filter(n => n.status === 'damaged' || n.status === 'repairing');
      if (damagedNodes.length > 0 && step < pDepth) {
        setTimeout(repairStep, 600);
      } else {
         document.getElementById('sim-status').innerText = 'IDLE';
         document.getElementById('sim-status').style.color = 'var(--text-main)';
         logStep(`[✓] Repair depth exhausted. Final coherence calculated.`, '#10b981');
      }
    }, 600);
  };

  repairStep();
};

// ==========================================
// 4. UI Events & Analytics
// ==========================================
const initUI = () => {
  const probSlider = document.getElementById('prob-slider');
  const depthSlider = document.getElementById('depth-slider');
  const nodesSlider = document.getElementById('nodes-slider');
  const tempSlider = document.getElementById('temp-slider');
  const glycationSlider = document.getElementById('glycation-slider');

  probSlider.addEventListener('input', e => { document.getElementById('prob-val').innerText = e.target.value; });
  depthSlider.addEventListener('input', e => { document.getElementById('depth-val').innerText = e.target.value; });
  
  nodesSlider.addEventListener('input', e => { document.getElementById('nodes-val').innerText = e.target.value; });
  tempSlider.addEventListener('input', e => { 
    document.getElementById('temp-val').innerText = parseFloat(e.target.value).toFixed(1); 
    window.COLLAGEN_ENV.temperature = parseFloat(e.target.value);
  });
  glycationSlider.addEventListener('input', e => { 
    document.getElementById('glycation-val').innerText = parseFloat(e.target.value).toFixed(2); 
    window.COLLAGEN_ENV.glycationLevel = parseFloat(e.target.value);
  });

  document.getElementById('btn-perturb').addEventListener('click', () => {
    const randomId = window.simNodes[Math.floor(Math.random() * window.simNodes.length)].id;
    applyDamage(randomId, parseFloat(probSlider.value));
  });

  const btnPerturbSelected = document.getElementById('btn-perturb-selected');
  if (btnPerturbSelected) {
    btnPerturbSelected.addEventListener('click', () => {
      if (window.selectedNodeId !== null) {
        applyDamage(window.selectedNodeId, parseFloat(probSlider.value));
      }
    });
  }

  document.getElementById('btn-repair').addEventListener('click', () => {
    simulateQAOA(parseInt(depthSlider.value));
  });

  document.getElementById('btn-reset').addEventListener('click', () => {
    logStep(`Resetting lattice to stable ground state...`, 'var(--health-repair)');
    window.simNodes.forEach(n => {
      n.health = 1.0;
      n.status = 'intact';
    });
    window.simLinks.forEach(l => l.intact = true);
    updateVisuals();
    setTimeout(() => logStep('Lattice reconstructed successfully.', '#10b981'), 300);
  });

  document.getElementById('btn-rebuild').addEventListener('click', () => {
    const N = parseInt(nodesSlider.value);
    buildLattice(N);
  });
};

let coherenceChart, distrChart;

const initCharts = () => {
  const ctxCoherence = document.getElementById('coherenceChart');
  const ctxDistr = document.getElementById('distributionChart');

  if (!ctxCoherence || !ctxDistr) return;

  Chart.defaults.color = '#475569';
  Chart.defaults.font.family = "'IBM Plex Mono', monospace";
  
  coherenceChart = new Chart(ctxCoherence, {
    type: 'line',
    data: {
      labels: Array(20).fill(''),
      datasets: [{
        label: 'System Coherence',
        data: Array(20).fill(1.0),
        borderColor: '#10b981',
        backgroundColor: 'rgba(16, 185, 129, 0.1)',
        borderWidth: 2,
        tension: 0.4,
        fill: true,
        pointRadius: 0
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        y: { min: 0, max: 1.1, grid: { color: 'rgba(255,255,255,0.05)' } },
        x: { grid: { display: false } }
      },
      animation: { duration: 0 }
    }
  });

  distrChart = new Chart(ctxDistr, {
    type: 'bar',
    data: {
      labels: ['Intact', 'Repaired', 'Repairing', 'Damaged'],
      datasets: [{
        data: [window.simNodes.length, 0, 0, 0],
        backgroundColor: [ '#10b981', '#4f46e5', '#f59e0b', '#ef4444' ],
        borderRadius: 4
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        y: { beginAtZero: true, grid: { color: 'rgba(255,255,255,0.05)' } },
        x: { grid: { display: false } }
      }
    }
  });
};

const updateMetrics = () => {
  const nodes = window.simNodes;
  const links = window.simLinks;

  const total = nodes.length;
  let intactEdges = links.filter(l => l.intact).length;
  let damagedNodes = nodes.filter(n => n.status === 'damaged').length;
  let repairedNodes = nodes.filter(n => n.status === 'repaired').length;
  let repairingNodes = nodes.filter(n => n.status === 'repairing').length;
  let intactNodes = nodes.filter(n => n.status === 'intact').length;

  const damageRatio = (damagedNodes / total) * 100;
  const maxEdges = links.length;
  const coherence = maxEdges > 0 ? ((intactNodes + repairedNodes * 0.9) / total) * (intactEdges / maxEdges) : 1;

  document.getElementById('metric-nodes').innerText = total;
  document.getElementById('metric-edges').innerText = intactEdges;
  
  const drEl = document.getElementById('metric-damage');
  drEl.innerText = damageRatio.toFixed(1) + '%';
  drEl.style.color = damageRatio > 20 ? '#ef4444' : (damageRatio > 0 ? '#f59e0b' : '#e8e8f0');

  const cohEl = document.getElementById('metric-coherence');
  cohEl.innerText = coherence.toFixed(2);
  cohEl.style.color = coherence > 0.8 ? '#10b981' : (coherence > 0.4 ? '#f59e0b' : '#ef4444');

  if (coherenceChart && distrChart) {
    const data = coherenceChart.data.datasets[0].data;
    data.shift();
    data.push(coherence);
    
    if(coherence < 0.4) coherenceChart.data.datasets[0].borderColor = '#ef4444';
    else if(coherence < 0.8) coherenceChart.data.datasets[0].borderColor = '#f59e0b';
    else coherenceChart.data.datasets[0].borderColor = '#10b981';

    coherenceChart.update();

    distrChart.data.datasets[0].data = [intactNodes, repairedNodes, repairingNodes, damagedNodes];
    distrChart.update();
  }
};

window.onload = () => {
  initThreeJS();
  initUI();
  initCharts();
  updateVisuals();
};
